repo_name = "7uddy/graphs"
base_commit = "1d2898157f7fde02cfc8d1d4c80705bca33c4cc2"
image_name = "maven:3.9.9-eclipse-temurin-23-alpine"
