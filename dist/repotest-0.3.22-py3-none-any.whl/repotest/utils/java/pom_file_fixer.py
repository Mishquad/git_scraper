import xml.etree.ElementTree as ET
import os
class PomFileFixer:
    REQUIRED_DEPENDENCIES = [
        {"groupId": "org.junit.jupiter", "artifactId": "junit-jupiter", "version": "5.8.1"},
        {"groupId": "org.testcontainers", "artifactId": "junit-jupiter", "version": "1.19.3"},
        {"groupId": "org.mockito", "artifactId": "mockito-core", "version": "4.6.0"},
        {"groupId": "org.mockito", "artifactId": "mockito-inline", "version": "4.6.0"},
        {"groupId": "io.projectreactor", "artifactId": "reactor-test", "version": "3.6.2"},
        {"groupId": "io.projectreactor", "artifactId": "reactor-core", "version": "3.6.2"},
        {"groupId": "org.assertj", "artifactId": "assertj-core", "version": "3.19.0"},
    ]

    @staticmethod
    def dependency_exists(dependencies, group_id, artifact_id, namespaces):
        for dependency in dependencies.findall('ns:dependency', namespaces):
            group_id_elem = dependency.find('ns:groupId', namespaces)
            artifact_id_elem = dependency.find('ns:artifactId', namespaces)
            if group_id_elem is not None and artifact_id_elem is not None:
                if group_id_elem.text == group_id and artifact_id_elem.text == artifact_id:
                    return True
        return False

    def fix_pom_file(self, fn_pom):
        tree = ET.parse(fn_pom)
        root = tree.getroot()
        namespaces = {'ns': 'http://maven.apache.org/POM/4.0.0'}

        dependencies = root.find('ns:dependencies', namespaces)
        if dependencies is None:
            dependencies = ET.SubElement(root, 'dependencies')

        for required_dep in self.REQUIRED_DEPENDENCIES:
            if not self.dependency_exists(dependencies, required_dep['groupId'], required_dep['artifactId'], namespaces):
                new_dependency = ET.SubElement(dependencies, 'dependency')
                ET.SubElement(new_dependency, 'groupId').text = required_dep['groupId']
                ET.SubElement(new_dependency, 'artifactId').text = required_dep['artifactId']
                ET.SubElement(new_dependency, 'version').text = required_dep['version']

        self.remove_namespace_prefix(tree, '{http://maven.apache.org/POM/4.0.0}')
        tree.write(fn_pom, encoding='UTF-8', xml_declaration=True)
        print("Dependencies checked and updated in pom.xml=%s"%fn_pom)

    @staticmethod
    def remove_namespace_prefix(tree, namespace):
        for elem in tree.iter():
            if elem.tag.startswith(namespace):
                elem.tag = elem.tag.split('}', 1)[1]

    def fix_pom_file_in_package(self, repo_folder):
        fn_pom = os.path.join(repo_folder, 'pom.xml')
        if not os.path.exists(fn_pom):
            fn_pom = os.path.join(repo_folder, 'java', 'pom.xml')

        if not os.path.exists(fn_pom):
            raise ValueError("Could't find pom file")
        print("fn_pom=%s"%fn_pom)
        self.fix_pom_file(fn_pom)