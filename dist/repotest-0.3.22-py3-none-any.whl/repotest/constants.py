import os
if os.path.exists("/data/adam"):
    DEFAULT_CACHE_FOLDER = "/data/adam/.cache/repotest"
else:    
    DEFAULT_CACHE_FOLDER = os.path.expanduser(os.getenv("REPOTEST_CACHE_FOLDER", "~/.cache/repotest"))

DEFAULT_CONTAINER_MEM_LIMIT = '10g'
print("DEFAULT_CACHE_FOLDER=%s"%DEFAULT_CACHE_FOLDER)
DEFAULT_TEST_EVAL_TIMEOUT = 80
DEFAULT_TEST_BUILD_TIMEOUT = 320

CONDA_ENV_NAME = "rt_venv_bench"
# DOCKER_IMAGE_PREFIX = "rt"
#ToDo: uncomment after debug
DOCKER_IMAGE_PREFIX = "rti-"
DOCKER_CONTAINER_PREFIX = "rtc-"
DOCKER_PYTHON_DEFAULT_IMAGE = "python:3.11.11-slim-bookworm"
DOCKER_JAVA_DEFAULT_IMAGE = "openjdk:17-slim"

import logging
LOG_LEVEL_FILE = logging.DEBUG
LOG_LEVEL_CONSOLE = logging.CRITICAL