from repotest.logger import logger
__version__ = "0.3.22"
logger.info("RepoTest initialised")