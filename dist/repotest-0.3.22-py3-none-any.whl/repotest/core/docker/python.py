import os
import docker
from docker.errors import DockerException
from repotest.core.docker.base import AbstractDockerRepo
from repotest.constants import DEFAULT_TEST_EVAL_TIMEOUT, DEFAULT_TEST_BUILD_TIMEOUT, DEFAULT_CACHE_FOLDER, DOCKER_PYTHON_DEFAULT_IMAGE
from repotest.utils.timeout import TimeOutException
import time
from functools import cached_property
from repotest.parsers.python.pytest_stdout import parse_pytest_stdout
import json

import logging
logger = logging.getLogger("repotest") 

class PythonDockerRepo(AbstractDockerRepo):
    """
    A class for managing and testing Python repositories in a Docker container.

    Attributes
    ----------
    test_timeout : int
        Maximum time (in seconds) to wait for test execution (default is 60 seconds).
    """
    def __init__(self, 
                 repo: str, 
                 base_commit: str,
                 default_cache_folder: str = DEFAULT_CACHE_FOLDER, 
                 default_url: str = 'http://github.com',
                 image_name: str = DOCKER_PYTHON_DEFAULT_IMAGE,
                 cache_mode: str = "volume"
                 ) -> None:
        """
        Initializes the Docker repository manager.

        Parameters
        ----------
        repo : str
            The repository name.
        base_commit : str
            The base commit for the repository.
        default_cache_folder : str, optional
            Default folder for cache storage (default is '~/.cache/repo_test/').
        default_url : str, optional
            The URL of the repository (default is 'http://github.com').
        image_name : str, optional
            The Docker image name to use (default is "maven:3.9.9-eclipse-temurin-23-alpine").
        cache_mode : str, optional
            The cache mode to use, must be one of ('download', 'shared', 'local', 'volume') (default is "volume").
        """
        super().__init__(repo=repo,
                         base_commit=base_commit,
                         default_cache_folder=default_cache_folder,
                         default_url=default_url,
                         image_name=image_name,
                         cache_mode=cache_mode)
    
    
    @cached_property
    def user_pip_cache(self):
        return os.path.expanduser("~/.cache/pip")
    
    @cached_property
    def local_pip_cache(self):
        return os.path.join(self.cache_folder, ".pip_cache")
    
    def build_env(self, 
                  command: str,
                  timeout: int = DEFAULT_TEST_BUILD_TIMEOUT
                 ) -> None:
        """
        Build the environment inside the Docker container.

        Parameters
        ----------
        command : str
            The command to execute inside the container.
        timeout : int, optional
            The maximum execution time allowed for the command (default is DEFAULT_TEST_BUILD_TIMEOUT).
        """
        res = self.run_test(command = command,
                            timeout = timeout,
                            stop_container = False
                           )
        if self._FALL_WITH_TIMEOUT_EXCEPTION:
            raise TimeOutException("Function '%s' timed out after %s seconds."%(command, timeout))
        
        #ToDo: add some rules to save only good images
        self.delete_image_if_exist(self.default_image_name)
        
        try:
            self.container.commit(self.default_image_name)
        except docker.errors.APIError as e:
            logger.critical(f"Can't commit image {self.default_image_name}")
            logger.error(e, exc_info=True)
            time.sleep(10)
            self.container.commit(self.default_image_name)
        
        logger.info("Change image name to currently created")
        self.image_name = self.default_image_name

        self.stop_container()
        return res
        # logger.info("build_env(%s, %s)"%(command, timeout))
        # logger.critical("build_env for %s is not implemented yet"%self)
        # pass

    def _image_exists(self, name):
        try:
            self.docker_client.images.get(name)
            return True
        except docker.errors.ImageNotFound:
            return False
        except docker.errors.APIError as e:
            logger.warning(f"Docker API error: {e}")
            return False
    
    @property
    def was_build(self):
        if self._image_exists(self.image_name):
            return True
        return Fals

    def __call__(self, 
                 command_build: str, 
                 command_test: str,
                 image_name_from: str = DOCKER_PYTHON_DEFAULT_IMAGE,
                 timeout_build:int = DEFAULT_TEST_BUILD_TIMEOUT,
                 timeout_test:int = DEFAULT_TEST_EVAL_TIMEOUT
                 ):
        """
        Runs the build and test process for the Python repository.

        Parameters
        ----------
        command_build : str
            Command to build the environment.
            timeout_build : int, optional
            Maximum time to wait for environment setup.
        """
        if not self.was_build:
            self.build_env(command = command_build, timeout=timeout_build)
        res = self.run_test(command = command_test, timeout=timeout_test)
        return res
    
    def _mock_path(self, command: str) -> str:
        """
        Mocks PATH to current folder.

        Parameters
        ----------
        command : str
            The command to modify.

        Returns
        -------
        str
            Modified command with environment settings."""
        #ToDo: understand why conda activate not working and fix this
        prefix = """export PYTHONPATH=$(pwd)
export PATH=$PYTHONPATH:$PATH
"""
        if not command.startswith(prefix):
            return prefix + command
        logger.debug("Export environment already in command.")
        return command

    def run_test(
        self,
        command="pytest tests",
        timeout=DEFAULT_TEST_EVAL_TIMEOUT,
        stop_container = True
    ):
        """
        Run a test command inside a Docker container.

        Parameters
        ----------
        command : str
            The command to execute inside the container.
        image_name : str
            The name of the Docker image to use for the container.
        pip_cache_mode : str
            Mode for handling the pip cache. Options are 'download', 'shared', or 'local'.

        Returns
        -------
        dict
            A dictionary containing the test results with the following keys:
            - 'stdout': str, standard output from the test execution.
            - 'stderr': str, standard error from the test execution.
            - 'returncode': int, the return code from the container.
        """
        if timeout != self._TEST_EVAL_TIMEOUT:
            logger.info(f"Setting timeout to {timeout} seconds.")
            self.set_timeout(timeout)
        logger.info("cache_mode: %s"%self.cache_mode)

        self.container_name = self.default_container_name

        volume_mount = {self.cache_folder: {'bind': self.cache_folder, 'mode': 'rw'}}

        if self.cache_mode == "shared":
            pip_cache = self.user_pip_cache
            volume_mount[pip_cache] = {'bind': pip_cache, 'mode': 'rw'}
        elif self.cache_mode == "local":
            pip_cache = self.local_pip_cache
            volume_mount[pip_cache] = {'bind': pip_cache, 'mode': 'rw'}

        logger.info(f"Running command in Docker container: {command}")
        logger.info(f"Using image: {self.image_name}")
        logger.info(f"Mounting volume: {self.cache_folder} to container.")

        self.start_container(image_name=self.image_name,
                            container_name=self.container_name,
                            volumes=volume_mount
                           )
        
        command = self._mock_path(command)
        
        try:
            self.evaluation_time = time.time()
            self.timeout_exec_run(f"bash -c '{command}'")
        except TimeOutException:
            logger.critical("Timeout exception %s"%self)
            self.return_code = 2
            self.stderr = b'Timeout exception'
        self.evaluation_time = time.time() - self.evaluation_time

        self._convert_std_from_bytes_to_str()

        fn_json_result = os.path.join(self.cache_folder, "report_pytest.json")
        pytest_json = {}
        if os.path.exists(fn_json_result):
            pytest_json = json.load(open(fn_json_result, 'r'))
        
        if stop_container and (not self._FALL_WITH_TIMEOUT_EXCEPTION):
            self.stop_container()
        
        return {
                'stdout': self.stdout,
                'stderr': self.stderr,
                'std': self.std,
                'returncode': self.return_code,
                "parser": parse_pytest_stdout(self.stdout), #ToDo: get code from realcode_v1
                "pytest_json": pytest_json,
                "time": self.evaluation_time
              }