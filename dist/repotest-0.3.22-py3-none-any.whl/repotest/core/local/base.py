from abc import abstractmethod
import subprocess
import logging
from repotest.core.base import AbstractRepo
from repotest.constants import DEFAULT_TEST_EVAL_TIMEOUT, DEFAULT_CACHE_FOLDER
from repotest.parsers.python.pytest_stdout import parse_pytest_stdout
from typing import Dict

logger = logging.getLogger("repotest")


class AbstractLocalRepo(AbstractRepo):
    """
    Base class for managing a local repository.

    Parameters
    ----------
    repo : str
        The repository name.
    base_commit : str
        The base commit for the repository.
    default_cache_folder : str, optional
        Default folder for cache storage (default is '~/.cache/repo_test/').
    default_url : str, optional
        The URL of the repository (default is 'http://github.com').

    Examples
    --------
    >>> repo = AbstractLocalRepo("myrepo", "abc123")
    """

    def __init__(
        self,
        repo: str,
        base_commit: str,
        default_cache_folder: str = DEFAULT_CACHE_FOLDER,
        default_url: str = "http://github.com",
    ) -> None:
        super().__init__(
            repo=repo,
            base_commit=base_commit,
            default_cache_folder=default_cache_folder,
            default_url=default_url,
        )

    def subprocess_run(self, command: str, timeout: int) -> Dict[str, str | int]:
        """
        Runs a shell command with a timeout using `subprocess.run`.

        Parameters
        ----------
        command : str
            The shell command to execute.
        timeout : int
            The maximum number of seconds to wait for execution.

        Returns
        -------
        dict
            A dictionary containing:
            - 'stdout': str, standard output from execution.
            - 'stderr': str, standard error from execution.
            - 'returncode': int, process return code.

        Examples
        --------
        >>> repo = AbstractLocalRepo("myrepo", "abc123")
        >>> repo.subprocess_run("echo 'Hello, World!'", 5)
        {'stdout': 'Hello, World!\\n', 'stderr': '', 'returncode': 0}
        """
        logger.critical(f"Executing command with timeout={timeout}:\n{command}")

        try:
            result = subprocess.run(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=self.cache_folder,
                text=True,
                timeout=timeout,
            )
            self.stdout = result.stdout
            self.stderr = result.stderr
            self.returncode = result.returncode

        except subprocess.TimeoutExpired:
            self.stdout = ""
            self.stderr = f"Test execution timed out after {timeout} seconds."
            self.returncode = -1  # Custom return code for timeout

        logger.info(f"Process finished with return code: {self.returncode}")

        return {
            "stdout": self.stdout,
            "stderr": self.stderr,
            "returncode": self.returncode,
        }

    def subprocess_popen(self, command: str, timeout: int) -> Dict[str, str | int]:
        """
        Runs a shell command asynchronously with real-time streaming.

        Parameters
        ----------
        command : str
            The shell command to execute.
        timeout : int
            The maximum number of seconds to wait for execution.

        Returns
        -------
        dict
            A dictionary containing:
            - 'stdout': str, standard output from execution.
            - 'stderr': str, standard error from execution.
            - 'returncode': int, process return code.

        Examples
        --------
        >>> repo = AbstractLocalRepo("myrepo", "abc123")
        >>> repo.subprocess_popen("echo 'Hello'", 5)
        {'stdout': 'Hello\\n', 'stderr': '', 'returncode': 0}
        """
        process = subprocess.Popen(
            command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=self.cache_folder,
            text=True,
            bufsize=1,
            universal_newlines=True,
        )

        self.stdout, self.stderr = "", ""

        try:
            for line in iter(process.stdout.readline, ""):
                if line:
                    logger.debug(line.strip())
                    self.stdout += line

            for line in iter(process.stderr.readline, ""):
                if line:
                    logger.warning(line.strip())
                    self.stderr += line

            process.wait(timeout)

        except subprocess.TimeoutExpired:
            process.kill()
            self.stderr += f"\nTest execution timed out after {timeout} seconds.\n"

        self.returncode = process.returncode

        return {
            "stdout": self.stdout,
            "stderr": self.stderr,
            "returncode": self.returncode,
        }
    
    @abstractmethod
    def build_env(self, command):
        pass
    
    @abstractmethod
    def run_test(self, command):
        pass
