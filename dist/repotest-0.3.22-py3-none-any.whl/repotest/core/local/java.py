import subprocess
from repotest.core.local.base import AbstractLocalRepo
from repotest.constants import DEFAULT_TEST_EVAL_TIMEOUT
from repotest.parsers.java.maven_stdout import analyze_maven_stdout

class JavaLocalRepo(AbstractLocalRepo):
    """
    A class for managing and testing local Java repositories.

    Attributes
    ----------
    test_timeout : int
        Maximum time (in seconds) to wait for test execution (default is 60 seconds).
    """
    def build_env(self, 
                  command: str,
                  timeout: int = DEFAULT_TEST_EVAL_TIMEOUT
                 ) -> None:
        raise NotImplementedError("build_env for JavaLocalRepo nnot implemented yet")
        self.run_test(command=command,
                      timeout=timeout
                     )
        pass

    def run_test(self, command = 'mvn test', timeout = DEFAULT_TEST_EVAL_TIMEOUT):
        """
        Run tests in the Java repository using Maven.

        Returns
        -------
        dict
            A dictionary containing the test results with the following keys:
            - 'stdout': str, standard output from the test execution.
            - 'stderr': str, standard error from the test execution.
            - 'returncode': int, the return code from the Maven process.
        
        Notes
        -----
        The method detects the location of the `pom.xml` file and runs the tests 
        from the appropriate directory. If the Maven command succeeds (return code 0),
        it prints a success message. Otherwise, it prints a failure message.
        """

        # To Do: delete this put this to the command; command is the input parametre
        # Determine the working directory for Maven

        # Run the Maven test command
        result = self.subprocess_popen(command=command, timeout=timeout)
        # process = subprocess.Popen(
        #     command,
        #     shell=True,
        #     stdout=subprocess.PIPE,
        #     stderr=subprocess.PIPE,
        #     cwd=self.cache_folder,
        # )
        
        # stdout, stderr = '', ''
        # try:
        #     stdout, stderr = process.communicate(timeout=timeout)
        #     stdout = stdout.decode("utf-8", errors = "replace") if stdout else ""
        #     stderr = stderr.decode("utf-8", errors = "replace") if stderr else ""
        # except subprocess.TimeoutExpired:
        #     process.kill()
        #     stderr += f"\nTest execution timed out after {timeout} seconds."
        
        # returncode = process.returncode
        # print(f"Process return code: {returncode}")
        result['parser'] = analyze_maven_stdout(stdout=result['stdout'], full_path=self.default_cache_folder)
        # Prepare the result dictionary
        # result = {
        #     'stdout': stdout,
        #     'stderr': stderr,
        #     'returncode': returncode,
        #     "parser": analyze_maven_stdout(stdout=stdout, 
        #                                    full_path=self.default_cache_folder
        #                                    )
        #     }

        # Log success or failure
        if result['returncode'] == 0:
            print(f"Success [{self.repo}]")
        else:
            print(f"Fail [{self.repo}]")
            print("stdout")
            print(result['stdout'])

            print("stderr")
            print(result['stderr'])

        return result
